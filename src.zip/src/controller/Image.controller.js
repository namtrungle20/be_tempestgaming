import path from 'path';
import fs from 'fs';
import cloudinary from '../config/cloudinaryConfig.js';
import db from "../models/index.js";




export async function uploadImages(req, res) {
    if (!req.files || req.files.length === 0) {
        throw new Error('Không có file nào được tải lên')
    }
    const uploadImagePaths = req.files.map(file => ({
        filename: path.basename(file.path),
        originalname: file.originalname
    }));
    res.status(201).json({
        message: 'Tải ảnh thành công',
        file: uploadImagePaths
    })
}

export const uploadToLibrary = async (req, res) => {
    if (!req.uploadedImages?.length) throw { status: 400, message: 'Không có file ảnh' };
    return res.status(201).json({
        success: true,
        data: req.uploadedImages.map(img =>
        ({
            url: img.url,
            public_id: img.public_id
        })),
    });
};

export const assignToProduct = async (req, res) => {
    const { sanpham_id, image_url, public_id } = req.body;
    if (!sanpham_id || !image_url) throw { status: 400, message: 'Thiếu sanpham_id hoặc image_url' };

    const sanpham = await db.SanPham.findByPk(sanpham_id);
    if (!sanpham) throw { status: 404, message: 'Sản phẩm không tồn tại' };

    const existed = await db.HinhAnhSanPham.findOne({ where: { sanpham_id, image_url } });
    if (existed) throw { status: 409, message: 'Ảnh đã được gán vào sản phẩm này' };

    const count = await db.HinhAnhSanPham.count({ where: { sanpham_id } });
    const newImage = await db.HinhAnhSanPham.create({
        sanpham_id,
        image_url,
        public_id: public_id || null,
        la_anh_dai_dien: count === 0,
    });

    return res.status(201).json({ success: true, data: newImage });
};


export async function uploadImageToCloudinaryOnly(req, res) {
    try {
        if (!req.file) {
            return res.status(400).json({ message: 'Không có file ảnh nào được upload!' });
        }
        const image_url = req.file.path; // do middleware Cloudinary cung cấp
        return res.status(201).json({
            success: true,
            message: 'Tải ảnh lên Cloudinary thành công',
            url: image_url,
            public_id: req.file.public_id
        });
    } catch (error) {
        return res.status(500).json({ success: false, message: error.message });
    }
}

// async function checkImageInUse(imageUrl) {
//     const checks = [
//         { model: db.NguoiDung, field: 'avatar' },
//         { model: db.ThuongHieu, field: 'image' },
//         // { model: db.SanPham, field: 'image' },
//         { model: db.LoaiSanPham, field: 'image' },
//     ];

//     for (let { model, field } of checks) {
//         const result = await model.findOne({ where: { [field]: imageUrl } });
//         if (result) {
//             return { inUse: true, model: model.name || 'Unknown', field };
//         }
//     }

//     return { inUse: false };
// }
async function checkImageInUse(imageUrl) {
    const inHinhAnh = await db.HinhAnhSanPham.findOne({ where: { image_url: imageUrl } });
    if (inHinhAnh) {
        return { inUse: true, model: 'HinhAnhSanPham', field: 'image_url' };
    }
    const user = await db.NguoiDung.findOne({ where: { avatar: imageUrl } });
    if (user) {
        return { inUse: true, model: 'NguoiDung', field: 'avatar' };
    }
    const brand = await db.ThuongHieu.findOne({ where: { image: imageUrl } });
    if (brand) {
        return { inUse: true, model: 'ThuongHieu', field: 'image' };
    }
    return { inUse: false };
}


export async function deleteImage(req, res) {
    const { url: rawUrl } = req.body;

    // 1. Kiểm tra đầu vào
    if (!rawUrl || typeof rawUrl !== 'string') {
        return res.status(400).json({ message: 'Thiếu đường dẫn ảnh cần xoá!' });
    }

    const url = rawUrl.trim();

    // 2. Kiểm tra ảnh có đang được sử dụng trong DB không (Dùng hàm check đã viết của ông)
    const check = await checkImageInUse(url);
    if (check.inUse) {
        return res.status(400).json({
            message: `Ảnh đang được sử dụng trong {${check.model}.${check.field}}, không thể xoá!`,
        });
    }

    // 3. Xử lý xóa ảnh trên Cloudinary
    if (url.includes('https://res.cloudinary.com/')) {
        try {
            const parts = url.split('/');
            const fileName = parts.pop();
            let afterUpload = parts.slice(parts.indexOf('upload') + 1);

            // Bỏ version (v123...)
            if (afterUpload[0]?.startsWith('v') && !isNaN(afterUpload[0].substring(1))) {
                afterUpload = afterUpload.slice(1);
            }

            const folder = afterUpload.join('/');
            const publicId = folder + '/' + fileName.split('.')[0];

            const result = await cloudinary.uploader.destroy(publicId);

            if (result.result === 'ok') {
                return res.status(200).json({ message: 'Ảnh Cloudinary đã được xoá thành công!' });
            } else {
                return res.status(404).json({ message: 'Không tìm thấy ảnh trên Cloudinary (có thể đã xóa trước đó)!' });
            }
        } catch (error) {
            return res.status(500).json({ message: 'Lỗi khi xóa ảnh trên Cloudinary', error: error.message });
        }
    }

    // 4. Xử lý xóa ảnh Local (Dùng fs.promises để code sạch hơn)
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
        try {
            // Lấy đúng tên file từ URL gửi lên (tránh lỗi path nếu gửi kèm slug/api/images/)
            const fileName = path.basename(url);
            const filePath = path.join(process.cwd(), 'uploads', fileName);

            // Kiểm tra xem file có thực sự tồn tại trên đĩa không trước khi xóa
            if (fs.existsSync(filePath)) {
                await fs.promises.unlink(filePath);
                return res.status(200).json({ message: 'Ảnh local đã được xoá thành công!' });
            } else {
                // Nếu không thấy file trên đĩa, coi như đã xóa để tránh báo lỗi cho người dùng
                return res.status(200).json({ message: 'File không tồn tại trên hệ thống, coi như đã xóa.' });
            }
        } catch (error) {
            console.error("Lỗi xóa file local:", error);
            return res.status(500).json({ message: 'Lỗi hệ thống khi xóa file ảnh local' });
        }
    }

    return res.status(400).json({ message: 'Định dạng URL hoặc Host không được hỗ trợ!' });
}



export async function viewImage(req, res) {
    try {
        const { fileName } = req.params
        const decodedFileName = decodeURIComponent(fileName);
        const imagePath = path.join(process.cwd(), 'uploads', decodedFileName);
        if (fs.existsSync(imagePath)) {
            return res.sendFile(imagePath);
        } else {
            console.error("Không tìm thấy file tại:", imagePath);
            return res.status(404).send('Không tìm thấy ảnh');
        }
    } catch (error) {
        console.error("Lỗi viewImage:", error);
        return res.status(500).send('Lỗi server khi hiển thị ảnh');
    }
}

export async function getAllCloudinaryImages(req, res) {
    const { next_cursor, max_results = 24 } = req.query

    const result = await cloudinary.api.resources({
        type: 'upload',
        resource_type: 'image',
        max_results: Math.min(Number(max_results) || 24, 100),
        next_cursor: next_cursor || undefined,
    });

    const images = result.resources.map((img) => ({
        public_id: img.public_id,
        url: img.secure_url,
        format: img.format,
        created_at: img.created_at,
        bytes: img.bytes,
        width: img.width,
        height: img.height,
        folder: img.folder || null,
    }));

    return res.status(200).json({
        images,
        next_cursor: result.next_cursor || null,
        has_more: !!result.next_cursor,
    });

}

